object AndroidConfig {
    const val compileSdk = 34
    const val minSdk = 21
    const val targetSdk = 34
}
