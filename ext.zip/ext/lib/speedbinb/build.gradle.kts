plugins {
    id("lib-android")
}

dependencies {
    implementation(project(":lib:textinterceptor"))
}
